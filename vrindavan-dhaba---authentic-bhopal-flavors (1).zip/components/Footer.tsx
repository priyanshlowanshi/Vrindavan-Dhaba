
import React from 'react';
import { RESTAURANT_INFO } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-950 text-white py-12 border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <div className="mb-8 md:mb-0 text-center md:text-left">
            <div className="text-2xl font-bold mb-2">
              <span className="font-serif">VRINDAVAN</span> <span className="text-amber-500">DHABA</span>
            </div>
            <p className="text-stone-500 max-w-sm">
              Bringing the authentic taste of Indian dhaba culture to the heart of Bhopal.
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-8">
            <a href="#" className="text-stone-400 hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="text-stone-400 hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="text-stone-400 hover:text-white transition-colors">Refund Policy</a>
            <a href="#" className="text-stone-400 hover:text-white transition-colors">Sitemap</a>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-stone-500 text-sm">
          <p>© {new Date().getFullYear()} Vrindavan Dhaba. All Rights Reserved.</p>
          <p className="mt-4 md:mt-0 flex items-center">
            Designed with <i className="fas fa-heart text-red-700 mx-2"></i> for Bhopal's Foodies
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
