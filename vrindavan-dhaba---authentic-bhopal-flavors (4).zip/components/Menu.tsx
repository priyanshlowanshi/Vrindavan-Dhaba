
import React, { useState } from 'react';
import { MENU_ITEMS } from '../constants';
import { MenuItem } from '../types';

const categories: MenuItem['category'][] = ['Thali', 'Curry', 'Bread', 'Beverage'];

const Menu: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<MenuItem['category'] | 'All'>('All');

  const filteredItems = activeCategory === 'All' 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === activeCategory);

  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-12">
        <h2 className="text-amber-800 text-sm font-bold uppercase tracking-[0.2em] mb-4">Our Delicious Offerings</h2>
        <h3 className="text-4xl md:text-5xl font-serif text-stone-900 mb-6">Explore the Menu</h3>
        
        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          <button 
            onClick={() => setActiveCategory('All')}
            className={`px-6 py-2 rounded-full font-bold transition-all ${
              activeCategory === 'All' 
                ? 'bg-red-800 text-white' 
                : 'bg-white text-stone-600 hover:bg-amber-100'
            }`}
          >
            All Items
          </button>
          {categories.map(cat => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2 rounded-full font-bold transition-all ${
                activeCategory === cat 
                  ? 'bg-red-800 text-white' 
                  : 'bg-white text-stone-600 hover:bg-amber-100'
              }`}
            >
              {cat}s
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredItems.map(item => (
          <div key={item.id} className="bg-white rounded-2xl overflow-hidden shadow-lg group hover:shadow-2xl transition-all border border-stone-200">
            <div className="relative h-60 overflow-hidden">
              <img 
                src={item.image} 
                alt={item.name} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              {item.isPopular && (
                <div className="absolute top-4 left-4 bg-amber-500 text-stone-900 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-lg">
                  <i className="fas fa-fire mr-1"></i> Popular
                </div>
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button className="bg-white text-red-800 font-bold px-6 py-2 rounded-full transform translate-y-4 group-hover:translate-y-0 transition-transform">
                  Add to Cart
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="flex justify-between items-start mb-2">
                <h4 className="text-xl font-bold text-stone-900">{item.name}</h4>
                <span className="text-red-700 font-bold text-lg">₹{item.price}</span>
              </div>
              <p className="text-stone-500 text-sm leading-relaxed mb-4">
                {item.description}
              </p>
              <div className="flex items-center text-xs text-amber-600 font-semibold uppercase tracking-wider">
                <i className="fas fa-tag mr-2"></i> {item.category}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="text-center mt-12">
        <p className="text-stone-500 italic mb-6">Prices are exclusive of taxes. Custom thalis available for bulk orders.</p>
        <button className="inline-flex items-center text-red-800 font-bold hover:underline">
          View Full Menu as PDF <i className="fas fa-external-link-alt ml-2"></i>
        </button>
      </div>
    </div>
  );
};

export default Menu;
