
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
      <div className="relative">
        <img 
          src="https://picsum.photos/seed/dhaba-food/800/600" 
          alt="Vrindavan Dhaba Ambience" 
          className="rounded-2xl shadow-2xl z-10 relative"
        />
        <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-amber-400 rounded-2xl -z-0 hidden md:block"></div>
        <div className="absolute top-1/2 -left-8 -translate-y-1/2 bg-red-800 text-white p-6 rounded-xl shadow-xl z-20 hidden md:block max-w-[200px]">
          <span className="text-4xl font-serif block mb-2">10+</span>
          <span className="text-sm font-medium uppercase tracking-wider">Years of culinary excellence in Bhopal</span>
        </div>
      </div>
      
      <div>
        <h2 className="text-amber-800 text-sm font-bold uppercase tracking-[0.2em] mb-4">Our Legacy</h2>
        <h3 className="text-4xl md:text-5xl text-stone-900 mb-6 leading-tight">
          A Tradition of Taste and <span className="text-red-800 italic">Hospitality</span>
        </h3>
        <p className="text-stone-600 text-lg mb-8 leading-relaxed">
          Vrindavan Dhaba has evolved from a humble roadside stop into one of Bhopal’s most iconic dining destinations. 
          Strategically located on Narmadapuram Road, we take pride in serving high-volume, 
          fast-moving traditional Indian cuisine that doesn't compromise on flavor or quality.
        </p>
        <p className="text-stone-600 text-lg mb-10 leading-relaxed">
          Whether you're a traveler looking for a satisfying break, a family celebrating a special occasion, 
          or just craving the rich, buttery taste of North India, we're here to serve you with a smile 
          and portions that will keep you coming back.
        </p>
        
        <div className="grid grid-cols-2 gap-6">
          <div className="flex items-start">
            <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center text-amber-800 mr-4 flex-shrink-0">
              <i className="fas fa-wallet text-xl"></i>
            </div>
            <div>
              <h4 className="font-bold mb-1">Affordable</h4>
              <p className="text-sm text-stone-500">Value for money thalis starting at ₹200.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center text-amber-800 mr-4 flex-shrink-0">
              <i className="fas fa-bolt text-xl"></i>
            </div>
            <div>
              <h4 className="font-bold mb-1">Fast Service</h4>
              <p className="text-sm text-stone-500">Optimized kitchen for busy highway traffic.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
