
import React, { useState, useEffect } from 'react';
import { Section } from '../types';

interface HeaderProps {
  activeSection: Section;
}

const Header: React.FC<HeaderProps> = ({ activeSection }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', id: Section.HOME },
    { label: 'About', id: Section.ABOUT },
    { label: 'Menu', id: Section.MENU },
    { label: 'Reviews', id: Section.REVIEWS },
    { label: 'Contact', id: Section.CONTACT },
  ];

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-amber-50 shadow-md py-3' : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div 
          className={`text-2xl font-bold cursor-pointer transition-colors ${
            isScrolled ? 'text-red-800' : 'text-white'
          }`}
          onClick={() => scrollTo(Section.HOME)}
        >
          <span className="font-serif">VRINDAVAN</span> <span className="text-amber-500">DHABA</span>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center space-x-8">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className={`text-sm font-semibold uppercase tracking-wider hover:text-amber-500 transition-colors ${
                activeSection === item.id 
                  ? 'text-amber-500 underline underline-offset-8' 
                  : isScrolled ? 'text-stone-700' : 'text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button 
            className="bg-red-700 text-white px-6 py-2 rounded-full font-bold hover:bg-red-800 transition-all transform hover:scale-105"
            onClick={() => scrollTo(Section.MENU)}
          >
            ORDER ONLINE
          </button>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className={`lg:hidden text-2xl ${isScrolled ? 'text-stone-800' : 'text-white'}`}
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`lg:hidden fixed inset-0 bg-amber-50 transition-transform duration-300 transform ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        } z-40`}
      >
        <div className="flex flex-col items-center justify-center h-full space-y-8 p-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="text-2xl font-serif text-stone-800 hover:text-red-800"
            >
              {item.label}
            </button>
          ))}
          <button 
            className="bg-red-700 text-white px-8 py-3 rounded-full text-xl font-bold"
            onClick={() => scrollTo(Section.MENU)}
          >
            ORDER ONLINE
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
