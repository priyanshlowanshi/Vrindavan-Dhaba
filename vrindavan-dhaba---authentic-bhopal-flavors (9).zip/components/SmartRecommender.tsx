import React, { useState } from 'react';
import { getDishRecommendation } from '../services/gemini';

const moods = [
  { label: 'Hungry 😋', value: 'extremely hungry and craving a heavy meal' },
  { label: 'Adventurous 🌶️', value: 'adventurous and wanting something spicy' },
  { label: 'Comfortable 🏠', value: 'looking for home-like comfort food' },
  { label: 'Light 🥗', value: 'looking for something light yet flavorful' }
];

const SmartRecommender: React.FC = () => {
  const [recommendation, setRecommendation] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleRecommend = async (mood: string) => {
    setIsLoading(true);
    try {
      const result = await getDishRecommendation(mood);
      setRecommendation(result);
    } catch (error) {
      setRecommendation("Our Vrindavan Special Thali is perfect for any mood! It's a complete meal with all our favorites.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 text-center">
      <div className="max-w-2xl mx-auto">
        <div className="inline-block bg-amber-500/20 text-amber-400 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4 border border-amber-500/30">
          Smart Waiter AI
        </div>
        <h3 className="text-3xl md:text-4xl font-serif mb-4 text-white">What's the Mood Today?</h3>
        <p className="text-amber-200/80 mb-10 text-lg">Indecisive? Let our AI suggest the perfect Bhopali flavors for you.</p>
        
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
          {moods.map(m => (
            <button 
              key={m.label}
              onClick={() => handleRecommend(m.value)}
              disabled={isLoading}
              className={`
                px-4 py-4 rounded-2xl border transition-all duration-300 disabled:opacity-50 group
                ${isLoading ? 'bg-white/5 border-white/10' : 'bg-white/10 hover:bg-amber-500 hover:text-stone-900 border-white/20 hover:border-amber-500 hover:shadow-[0_0_20px_rgba(245,158,11,0.3)]'}
              `}
            >
              <span className="text-sm font-bold block transition-transform group-hover:scale-105">{m.label}</span>
            </button>
          ))}
        </div>

        <div className="min-h-[160px] flex items-center justify-center">
          {isLoading ? (
            <div className="flex flex-col items-center gap-4">
              <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin shadow-[0_0_15px_rgba(245,158,11,0.5)]"></div>
              <div className="text-amber-400 italic font-medium animate-pulse">Consulting the chef...</div>
            </div>
          ) : recommendation ? (
            <div className="bg-white text-stone-900 p-8 rounded-[2rem] shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-500 relative border-t-8 border-amber-500">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-500 text-stone-900 text-[10px] font-black px-4 py-1 rounded-full uppercase tracking-widest shadow-lg">
                Recommended
              </div>
              <div className="flex justify-center mb-4 text-amber-500/20">
                <i className="fas fa-quote-left text-4xl"></i>
              </div>
              <p className="text-xl md:text-2xl italic leading-relaxed font-semibold text-stone-800">
                "{recommendation}"
              </p>
              <button 
                onClick={() => {
                  const menu = document.getElementById('menu');
                  if (menu) {
                    const offset = 80;
                    const bodyRect = document.body.getBoundingClientRect().top;
                    const elementRect = menu.getBoundingClientRect().top;
                    const elementPosition = elementRect - bodyRect;
                    const offsetPosition = elementPosition - offset;
                    window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
                  }
                }}
                className="mt-8 bg-red-700 text-white px-8 py-3 rounded-full font-bold text-sm uppercase tracking-wider hover:bg-red-800 transition-all flex items-center justify-center mx-auto shadow-lg hover:shadow-red-900/20"
              >
                Order this Dish <i className="fas fa-arrow-right ml-2"></i>
              </button>
            </div>
          ) : (
            <div className="p-10 border-2 border-dashed border-white/20 rounded-[2rem] w-full bg-white/5">
              <i className="fas fa-utensils text-white/10 text-4xl mb-4"></i>
              <p className="text-white/40 text-sm uppercase tracking-[0.3em]">Pick a mood to start</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SmartRecommender;