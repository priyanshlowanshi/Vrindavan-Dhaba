
import React from 'react';

const features = [
  {
    icon: 'fa-utensils',
    title: 'Dine-in',
    desc: 'Spacious seating for families and large groups.'
  },
  {
    icon: 'fa-car',
    title: 'Drive-through',
    desc: 'Grab your favorite meal without leaving your car.'
  },
  {
    icon: 'fa-mobile-alt',
    title: 'Online Ordering',
    desc: 'Order via our website or delivery partners.'
  },
  {
    icon: 'fa-box-open',
    title: 'No-contact Delivery',
    desc: 'Safe and secure delivery to your doorstep.'
  }
];

const Features: React.FC = () => {
  return (
    <div className="bg-red-900 py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((f, idx) => (
            <div key={idx} className="bg-white/5 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:bg-white/10 transition-all text-center group">
              <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center text-red-900 text-2xl mx-auto mb-6 group-hover:scale-110 transition-transform">
                <i className={`fas ${f.icon}`}></i>
              </div>
              <h4 className="text-xl font-bold text-white mb-2">{f.title}</h4>
              <p className="text-white/70">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;
