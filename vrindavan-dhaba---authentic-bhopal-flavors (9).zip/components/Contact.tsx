
import React from 'react';
import { RESTAURANT_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div>
          <h2 className="text-amber-500 text-sm font-bold uppercase tracking-[0.2em] mb-4">Get In Touch</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-white mb-8">Visit Us Today</h3>
          
          <div className="space-y-8">
            <div className="flex items-start">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-amber-500 mr-6 flex-shrink-0">
                <i className="fas fa-map-marker-alt text-xl"></i>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Our Location</h4>
                <p className="text-stone-400">{RESTAURANT_INFO.address}</p>
                <button className="text-amber-500 text-sm font-bold mt-2 hover:underline">
                  OPEN IN GOOGLE MAPS
                </button>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-amber-500 mr-6 flex-shrink-0">
                <i className="fas fa-phone-alt text-xl"></i>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Call Us</h4>
                <p className="text-stone-400">{RESTAURANT_INFO.phone}</p>
                <p className="text-xs text-stone-500">Available 11:00 AM - 11:30 PM</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-amber-500 mr-6 flex-shrink-0">
                <i className="fas fa-clock text-xl"></i>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Operating Hours</h4>
                <p className="text-stone-400">{RESTAURANT_INFO.timings} - 11:30 PM</p>
                <p className="text-xs text-stone-500">Open all 7 days of the week</p>
              </div>
            </div>
          </div>

          <div className="mt-12 flex space-x-4">
            <a href="#" className="w-12 h-12 bg-white/5 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-all">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="#" className="w-12 h-12 bg-white/5 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-all">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="#" className="w-12 h-12 bg-white/5 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-all">
              <i className="fab fa-whatsapp"></i>
            </a>
          </div>
        </div>

        <div className="relative rounded-3xl overflow-hidden shadow-2xl h-[400px] lg:h-auto border border-white/10">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3667.643329124443!2d77.4601138760037!3d23.18320491031383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x397c41f6e0f8f8b9%3A0xe549646be2208ec6!2sVrindavan%20Dhaba!5e0!3m2!1sen!2sin!4v1709462153215!5m2!1sen!2sin" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen={true} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="Google Maps Location"
          ></iframe>
          <div className="absolute bottom-4 right-4 bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-white text-xs">
            <i className="fas fa-info-circle mr-2"></i> Easily accessible on the Narmadapuram highway.
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
