
import { GoogleGenAI } from "@google/genai";

// Always initialize GoogleGenAI with process.env.API_KEY as a direct property
export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getDishRecommendation(mood: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a waiter at Vrindavan Dhaba, a famous rustic Indian restaurant in Bhopal.
      A customer is feeling ${mood}. 
      Based on our menu (Special Thali, Dal Bati, Kadhai Paneer, Butter Chicken, Tandoori Roti), suggest ONE dish.
      Keep it brief, friendly, and in the voice of a dhaba waiter.
      Response should be under 40 words.`,
    });
    return response.text || "I recommend our Special Thali! It has a bit of everything to make you happy.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Our Special Thali is always a winner!";
  }
}

/**
 * Utility to decode base64 string to Uint8Array
 * Following manual implementation from guidelines
 */
export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Utility to encode Uint8Array to base64 string
 * Following manual implementation from guidelines
 */
export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Utility to decode raw PCM audio data into an AudioBuffer
 * Following manual implementation from guidelines
 */
export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
