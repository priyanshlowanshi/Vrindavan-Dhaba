import { GoogleGenAI } from "@google/genai";

// Always initialize GoogleGenAI with process.env.API_KEY as a direct property
export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getDishRecommendation(mood: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a waiter at Vrindavan Dhaba, a famous rustic Indian restaurant in Bhopal.
      A customer is feeling ${mood}. 
      Based on our menu (Special Thali, Dal Bati, Kadhai Paneer, Butter Chicken, Tandoori Roti), suggest ONE dish.
      Keep it brief, friendly, and in the voice of a dhaba waiter.
      Response should be under 40 words.`,
    });
    // Correctly using .text property from GenerateContentResponse
    return response.text || "I recommend our Special Thali! It has a bit of everything to make you happy.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Our Special Thali is always a winner!";
  }
}

// Added manual base64 encoding/decoding and audio decoding for Live API support as per guidelines

/**
 * Encodes a Uint8Array to a base64 string.
 */
export function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Decodes a base64 string to a Uint8Array.
 */
export function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Decodes raw PCM audio bytes into an AudioBuffer for browser playback.
 */
export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
