
import React from 'react';
import { RESTAURANT_INFO } from '../constants';
import { Section } from '../types';

const Hero: React.FC = () => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="relative h-screen flex items-center justify-center text-center rustic-gradient">
      <div className="container mx-auto px-4 z-10">
        <div className="flex justify-center mb-6">
          <div className="bg-amber-500/20 backdrop-blur-md px-4 py-1 rounded-full border border-amber-500/50 flex items-center">
            <i className="fas fa-star text-amber-400 mr-2"></i>
            <span className="text-white font-medium">
              {RESTAURANT_INFO.rating} ★ ({RESTAURANT_INFO.reviewsCount.toLocaleString()} Google Reviews)
            </span>
          </div>
        </div>
        
        <h1 className="text-5xl md:text-8xl text-white mb-4 leading-tight">
          Authentic Dhaba Flavours <br /> 
          <span className="text-amber-400">at Honest Prices</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-stone-200 mb-10 max-w-3xl mx-auto font-light">
          Taste the heritage of Bhopal's favorite stop for travelers and families alike. 
          Generous portions, rich curries, and warm hospitality.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button 
            onClick={() => scrollTo(Section.MENU)}
            className="w-full sm:w-auto bg-red-700 hover:bg-red-800 text-white px-10 py-4 rounded-full text-lg font-bold transition-all transform hover:scale-105 shadow-xl"
          >
            <i className="fas fa-utensils mr-2"></i>
            ORDER ONLINE
          </button>
          <button 
            onClick={() => scrollTo(Section.CONTACT)}
            className="w-full sm:w-auto bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/50 px-10 py-4 rounded-full text-lg font-bold transition-all transform hover:scale-105 shadow-xl"
          >
            <i className="fas fa-map-marker-alt mr-2"></i>
            GET DIRECTIONS
          </button>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <button onClick={() => scrollTo(Section.ABOUT)} className="text-white/60 hover:text-white">
          <i className="fas fa-chevron-down text-2xl"></i>
        </button>
      </div>
    </div>
  );
};

export default Hero;
