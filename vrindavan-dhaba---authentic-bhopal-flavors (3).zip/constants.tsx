
import { MenuItem, Review } from './types';

export const RESTAURANT_INFO = {
  name: "Vrindavan Dhaba",
  rating: 3.9,
  reviewsCount: 11567,
  address: "Narmadapuram Road, Ganesh Nagar, Chinar Fortune City, Bhopal, MP 462026",
  phone: "0755 407 4028",
  timings: "Opens at 11:00 AM",
  priceRange: "₹200–₹400",
  email: "hello@vrindavandhaba.com"
};

export const MENU_ITEMS: MenuItem[] = [
  {
    id: '1',
    name: "Vrindavan Special Thali",
    description: "Our signature thali featuring Dal Makhani, Paneer, Veg Curry, Raita, Jeera Rice, and 2 Butter Rotis.",
    price: 320,
    category: 'Thali',
    image: 'https://picsum.photos/seed/thali/400/300',
    isPopular: true
  },
  {
    id: '2',
    name: "Dal Bati Thali",
    description: "Traditional Rajasthani style Dal Bati with Churma and Ghee.",
    price: 280,
    category: 'Thali',
    image: 'https://picsum.photos/seed/dalbati/400/300',
    isPopular: true
  },
  {
    id: '3',
    name: "Kadhai Paneer",
    description: "Paneer cooked with bell peppers and freshly ground spices in a traditional kadhai.",
    price: 240,
    category: 'Curry',
    image: 'https://picsum.photos/seed/paneer/400/300',
    isPopular: true
  },
  {
    id: '4',
    name: "Butter Chicken",
    description: "Classic creamy tomato-based curry with succulent chicken pieces.",
    price: 350,
    category: 'Curry',
    image: 'https://picsum.photos/seed/chicken/400/300'
  },
  {
    id: '5',
    name: "Tandoori Roti",
    description: "Freshly baked whole wheat bread in a clay oven.",
    price: 15,
    category: 'Bread',
    image: 'https://picsum.photos/seed/roti/400/300'
  },
  {
    id: '6',
    name: "Masala Chaas",
    description: "Refreshing spiced buttermilk, perfect for digestion.",
    price: 40,
    category: 'Beverage',
    image: 'https://picsum.photos/seed/chaas/400/300'
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'r1',
    author: "Rahul Sharma",
    rating: 5,
    comment: "Best Dal Bati in Bhopal. The taste is consistently good and the prices are unbeatable.",
    date: "2 weeks ago"
  },
  {
    id: 'r2',
    author: "Priya Singh",
    rating: 4,
    comment: "Quick service and great portions. Perfect stop for family dinners on the highway.",
    date: "1 month ago"
  },
  {
    id: 'r3',
    author: "Ankit Verma",
    rating: 4,
    comment: "Authentic dhaba vibe. Their Kadhai Paneer is a must-try!",
    date: "3 weeks ago"
  }
];
