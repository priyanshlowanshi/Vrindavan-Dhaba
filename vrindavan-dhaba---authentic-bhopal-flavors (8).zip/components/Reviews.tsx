
import React from 'react';
import { REVIEWS, RESTAURANT_INFO } from '../constants';

const Reviews: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-amber-800 text-sm font-bold uppercase tracking-[0.2em] mb-4">Testimonials</h2>
        <h3 className="text-4xl md:text-5xl font-serif text-stone-900 mb-6">Why People Love Us</h3>
        <div className="flex items-center justify-center space-x-2 text-2xl mb-4">
          <span className="font-bold text-red-800">{RESTAURANT_INFO.rating}</span>
          <div className="flex text-amber-500">
            {[1, 2, 3, 4].map(i => <i key={i} className="fas fa-star"></i>)}
            <i className="fas fa-star-half-alt"></i>
          </div>
          <span className="text-stone-400 text-sm font-normal">({RESTAURANT_INFO.reviewsCount.toLocaleString()} Google Reviews)</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {REVIEWS.map(rev => (
          <div key={rev.id} className="bg-amber-50/50 p-8 rounded-3xl border border-amber-100 shadow-sm relative hover:shadow-md transition-shadow">
            <div className="absolute top-8 right-8 text-amber-200 text-6xl opacity-50 -z-0">
              <i className="fas fa-quote-right"></i>
            </div>
            <div className="flex text-amber-500 text-xs mb-4">
              {[...Array(rev.rating)].map((_, i) => <i key={i} className="fas fa-star"></i>)}
            </div>
            <p className="text-stone-700 italic mb-6 leading-relaxed relative z-10">
              "{rev.comment}"
            </p>
            <div className="flex items-center mt-auto">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center text-red-700 font-bold mr-3">
                {rev.author[0]}
              </div>
              <div>
                <h5 className="font-bold text-stone-900">{rev.author}</h5>
                <p className="text-xs text-stone-400">{rev.date} on Google</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <a 
          href="https://www.google.com/search?q=vrindavan+dhaba+bhopal+reviews" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-stone-200 hover:bg-stone-300 text-stone-700 px-8 py-3 rounded-full font-bold transition-all"
        >
          READ ALL REVIEWS
        </a>
      </div>
    </div>
  );
};

export default Reviews;
