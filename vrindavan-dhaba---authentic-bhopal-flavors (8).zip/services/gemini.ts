
import { GoogleGenAI } from "@google/genai";

// Always initialize GoogleGenAI with process.env.API_KEY as a direct property
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getDishRecommendation(mood: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a waiter at Vrindavan Dhaba, a famous rustic Indian restaurant in Bhopal.
      A customer is feeling ${mood}. 
      Based on our menu (Special Thali, Dal Bati, Kadhai Paneer, Butter Chicken, Tandoori Roti), suggest ONE dish.
      Keep it brief, friendly, and in the voice of a dhaba waiter.
      Response should be under 40 words.`,
    });
    // Access response text using the getter property, not as a method.
    return response.text || "I recommend our Special Thali! It has a bit of everything to make you happy.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Our Special Thali is always a winner!";
  }
}
