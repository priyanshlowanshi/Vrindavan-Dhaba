
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Menu from './components/Menu';
import Features from './components/Features';
import Reviews from './components/Reviews';
import Contact from './components/Contact';
import Footer from './components/Footer';
import SmartRecommender from './components/SmartRecommender';
import LiveAssistant from './components/LiveAssistant';
import { Section } from './types';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>(Section.HOME);

  // Intersection observer to track active section
  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 0.5,
    };

    const handleIntersect = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id as Section);
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersect, observerOptions);
    const sections = document.querySelectorAll('section');
    sections.forEach((section) => observer.observe(section));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="bg-amber-50 min-h-screen text-stone-900 overflow-x-hidden">
      <Header activeSection={activeSection} />
      
      <main>
        <section id={Section.HOME}>
          <Hero />
        </section>

        <section id={Section.ABOUT} className="py-20">
          <About />
        </section>

        <Features />

        <section id={Section.MENU} className="py-20 bg-stone-100">
          <Menu />
        </section>

        <section className="py-12 bg-amber-900 text-white">
          <SmartRecommender />
        </section>

        <section id={Section.REVIEWS} className="py-20">
          <Reviews />
        </section>

        <section id={Section.CONTACT} className="py-20 bg-stone-900 text-white">
          <Contact />
        </section>
      </main>

      <Footer />
      
      {/* AI Assistant Button */}
      <LiveAssistant />
      
      {/* Floating CTA for Mobile */}
      <div className="fixed bottom-6 right-6 lg:hidden z-50">
        <a 
          href="tel:07554074028" 
          className="bg-red-700 text-white p-4 rounded-full shadow-2xl flex items-center justify-center animate-bounce"
        >
          <i className="fas fa-phone-alt"></i>
        </a>
      </div>
    </div>
  );
};

export default App;
