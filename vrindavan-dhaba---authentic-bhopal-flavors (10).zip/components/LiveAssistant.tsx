
import React, { useState, useRef } from 'react';
import { Modality, LiveServerMessage } from '@google/genai';
import { ai, encode, decode, decodeAudioData } from '../services/gemini';

const LiveAssistant: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  // Store the session promise to prevent race conditions during initialization
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const startSession = async () => {
    setIsConnecting(true);
    try {
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputAudioContext;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              // Critical: Solely rely on sessionPromise resolution before sending input
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
              const buffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
              const source = outputAudioContext.createBufferSource();
              source.buffer = buffer;
              source.connect(outputAudioContext.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => {
                try { s.stop(); } catch(e) {}
              });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onclose: () => stopSession(),
          onerror: (e) => {
            console.error("Assistant Error:", e);
            stopSession();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: 'You are a friendly waiter at Vrindavan Dhaba in Bhopal. You help customers choose dishes from the menu (Special Thali, Dal Bati, Kadhai Paneer, Butter Chicken). Keep it hospitable and dhaba-style.',
        },
      });
      sessionPromiseRef.current = sessionPromise;
    } catch (err) {
      console.error(err);
      setIsConnecting(false);
    }
  };

  const stopSession = () => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => {
        try { session.close(); } catch (e) {}
      });
      sessionPromiseRef.current = null;
    }
    setIsActive(false);
    setIsConnecting(false);
    sourcesRef.current.forEach(s => {
      try { s.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();
  };

  return (
    <div className="fixed bottom-24 right-6 z-50 flex flex-col items-end gap-3">
      {isActive && (
        <div className="bg-white px-4 py-2 rounded-2xl shadow-xl text-stone-800 text-sm font-medium border border-amber-200 animate-bounce">
          "I'm listening, ask me anything!"
        </div>
      )}
      <button
        onClick={isActive ? stopSession : startSession}
        disabled={isConnecting}
        className={`
          w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-all transform active:scale-95
          ${isActive ? 'bg-red-700 text-white animate-pulse' : 'bg-amber-500 text-stone-900'}
          ${isConnecting ? 'opacity-50 cursor-not-allowed' : 'hover:scale-110'}
        `}
      >
        {isConnecting ? (
          <div className="w-6 h-6 border-2 border-stone-900 border-t-transparent rounded-full animate-spin"></div>
        ) : (
          <i className={`fas ${isActive ? 'fa-stop' : 'fa-microphone'} text-2xl`}></i>
        )}
      </button>
      {!isActive && !isConnecting && (
        <div className="text-[10px] uppercase tracking-widest font-bold text-amber-800 bg-amber-200/50 px-2 py-0.5 rounded">
          Talk to Waiter
        </div>
      )}
    </div>
  );
};

export default LiveAssistant;
