
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'Thali' | 'Curry' | 'Bread' | 'Beverage';
  image: string;
  isPopular?: boolean;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export enum Section {
  HOME = 'home',
  ABOUT = 'about',
  MENU = 'menu',
  REVIEWS = 'reviews',
  CONTACT = 'contact'
}
