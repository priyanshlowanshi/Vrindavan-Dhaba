
import React, { useState } from 'react';
import { getDishRecommendation } from '../services/gemini';

const moods = [
  { label: 'Hungry 😋', value: 'extremely hungry and craving a heavy meal' },
  { label: 'Adventurous 🌶️', value: 'adventurous and wanting something spicy' },
  { label: 'Comfortable 🏠', value: 'looking for home-like comfort food' },
  { label: 'Sweet Tooth 🍯', value: 'craving something sweet after a meal' }
];

const SmartRecommender: React.FC = () => {
  const [recommendation, setRecommendation] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleRecommend = async (mood: string) => {
    setIsLoading(true);
    const result = await getDishRecommendation(mood);
    setRecommendation(result);
    setIsLoading(false);
  };

  return (
    <div className="container mx-auto px-4 text-center">
      <div className="max-w-2xl mx-auto">
        <h3 className="text-3xl font-serif mb-4">Can't Decide What to Order?</h3>
        <p className="text-amber-200 mb-8">Tell us your mood, and our Smart Waiter (powered by AI) will suggest the perfect dish for you!</p>
        
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {moods.map(m => (
            <button 
              key={m.label}
              onClick={() => handleRecommend(m.value)}
              disabled={isLoading}
              className="bg-white/10 hover:bg-white/20 border border-white/30 text-white px-5 py-2 rounded-full transition-all disabled:opacity-50"
            >
              {m.label}
            </button>
          ))}
        </div>

        <div className="min-h-[100px] flex items-center justify-center">
          {isLoading ? (
            <div className="animate-pulse text-amber-400 italic">Thinking of the best flavors...</div>
          ) : recommendation ? (
            <div className="bg-amber-50 text-stone-900 p-6 rounded-2xl shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-500 text-xs font-bold px-3 py-1 rounded-full uppercase">Chef's Pick</div>
              <p className="text-lg italic leading-relaxed">"{recommendation}"</p>
            </div>
          ) : (
            <p className="text-white/40 text-sm">Select your mood above to start</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default SmartRecommender;
